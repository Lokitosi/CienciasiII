#!/bin/bash
cd src/outputs
chmod +x ./Program
./Program