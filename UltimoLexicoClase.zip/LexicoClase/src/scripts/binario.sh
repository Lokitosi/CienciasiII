#!/bin/bash
cd src/outputs
g++ ./Program.o -o Program
ls -la
exit 0