#!/bin/bash
cd src/outputs
as ../outputs/Program.s -o ../outputs/Program.o
ls -la ../outputs
exit 0