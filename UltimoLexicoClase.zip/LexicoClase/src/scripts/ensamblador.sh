#!/bin/bash
pwd
cd src/outputs
g++ -Wall -S ./Program.i
ls -la
exit 0 