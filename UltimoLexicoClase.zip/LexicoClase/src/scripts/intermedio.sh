#!/bin/bash
cd src/outputs
cpp ../outputs/Program.cpp > ../outputs/Program.i
ls -la ../outputs
exit 0